<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Area;
use App\Models\Empleado;
use Carbon\Carbon;
use DateTime;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Shared\Date as ExcelDate;

class PermisosEmpleadosController extends Controller
{
    private string $motivoImportado = 'Vacación histórica importada desde Excel/CSV de saldos.';

    public function index(Request $request)
    {
        $query = Empleado::with(['area', 'lider'])->orderBy('nombre');

        if ($request->filled('area_id')) {
            $query->where('area_id', $request->area_id);
        }

        if ($request->filled('activo')) {
            $query->where('activo', $request->activo === '1');
        }

        if ($request->filled('q')) {
            $q = trim($request->q);
            $normalizado = Str::upper(preg_replace('/[^A-Za-z0-9]/', '', $q));

            $query->where(function ($sub) use ($q, $normalizado) {
                $sub->where('nombre', 'like', "%{$q}%")
                    ->orWhere('correo', 'like', "%{$q}%")
                    ->orWhere('numero_empleado', 'like', "%{$q}%")
                    ->orWhere('curp', 'like', "%{$normalizado}%")
                    ->orWhere('rfc', 'like', "%{$normalizado}%")
                    ->orWhere('puesto', 'like', "%{$q}%");
            });
        }

        return view('admin.permisos-catalogos.empleados.index', [
            'empleados' => $query->paginate(25)->withQueryString(),
            'areas' => Area::orderBy('nombre')->get(),
            'lideres' => Empleado::where('es_lider', true)->orderBy('nombre')->get(),
            'filters' => $request->only(['area_id', 'activo', 'q']),
        ]);
    }

    public function importForm()
    {
        return view('admin.permisos-catalogos.empleados.importar');
    }

    public function import(Request $request)
    {
        $request->validate([
            'archivo' => ['required', 'file', 'mimes:csv,txt,xlsx,xls'],
        ]);

        $this->ensureImportSchema();

        $rows = $this->leerArchivo($request->file('archivo'));

        if (count($rows) < 2) {
            return back()->with('error', 'El archivo no tiene información suficiente para importar.');
        }

        [$headerRowIndex, $headers] = $this->detectHeaders($rows);

        if (empty($headers)) {
            return back()->with('error', 'No pude detectar encabezados como CLAVE, NOMBRE, DEPARTAMENTO, PUESTO o FECHA INGRESO.');
        }

        $creados = 0;
        $actualizados = 0;
        $omitidos = 0;
        $lideresCreados = 0;
        $areasCreadas = 0;
        $vacacionesCreadas = 0;
        $vacacionesOmitidas = 0;
        $vacacionesReemplazadas = 0;
        $errores = [];

        DB::beginTransaction();

        try {
            foreach ($rows as $rowIndex => $row) {
                if ($rowIndex <= $headerRowIndex) {
                    continue;
                }

                $numeroEmpleado = $this->limpiarTexto($this->value($row, $headers, [
                    'CLAVE',
                    'NUMERO_EMPLEADO',
                    'NO_EMPLEADO',
                    'N_EMPLEADO',
                    'ID_EMPLEADO',
                    'CODIGO',
                    'CODIGO_EMPLEADO',
                ]));

                $nombre = $this->limpiarTexto($this->value($row, $headers, [
                    'NOMBRE',
                    'NOMBRE_COMPLETO',
                    'EMPLEADO',
                    'COLABORADOR',
                    'TRABAJADOR',
                ]));

                if (! $numeroEmpleado && ! $nombre) {
                    $omitidos++;
                    continue;
                }

                if (! $nombre) {
                    $errores[] = 'Fila ' . ($rowIndex + 1) . ': se omitió porque no tiene nombre.';
                    $omitidos++;
                    continue;
                }

                $departamento = $this->limpiarTexto($this->value($row, $headers, [
                    'DEPARTAMENTO',
                    'AREA',
                    'AREA_DEPARTAMENTO',
                    'DEPTO',
                    'SUCURSAL',
                ]));

                $puesto = $this->limpiarTexto($this->value($row, $headers, [
                    'PUESTO',
                    'NOMBRE_PUESTO',
                    'CARGO',
                    'POSICION',
                    'POSICIÓN',
                ]));

                $jefeDirecto = $this->limpiarTexto($this->value($row, $headers, [
                    'JEFE_DIRECTO',
                    'JEFE',
                    'LIDER',
                    'LÍDER',
                    'LIDER_DIRECTO',
                    'RESPONSABLE',
                ]));

                $fechaIngreso = $this->fecha($this->value($row, $headers, [
                    'FECHA_INGRESO',
                    'FECHA_DE_INGRESO',
                    'INGRESO',
                    'FECHA_ALTA',
                    'FECHA_ENTRADA',
                ]));

                $correo = $this->limpiarTexto($this->value($row, $headers, [
                    'CORREO',
                    'EMAIL',
                    'CORREO_ELECTRONICO',
                    'CORREO_ELECTRÓNICO',
                ]));

                $curp = $this->normalizarClave($this->value($row, $headers, ['CURP']));
                $rfc = $this->normalizarClave($this->value($row, $headers, ['RFC']));

                $diasGanadosAlDia = $this->decimal($this->value($row, $headers, [
                    'DIAS_GANADOS_AL_DIA_DE_HOY_MAS_LOS_PROPORCIONALES_DEL_ANO_ACTUAL',
                    'DIAS_GANADOS_AL_DIA_DE_HOY_MÁS_LOS_PROPORCIONALES_DEL_AÑO_ACTUAL',
                    'DIAS_GANADOS_AL_DIA_DE_HOY',
                    'DIAS_VACACIONES_GANADOS',
                    'DIAS_GANADOS',
                ]));

                $diasDisponiblesExcel = $this->decimal($this->value($row, $headers, [
                    'PROPORCIONALES',
                    'DIAS_PROPORCIONALES',
                    'SALDO',
                    'SALDO_VACACIONES',
                    'DIAS_DISPONIBLES',
                    'DIAS_VACACIONES_DISPONIBLES',
                    'VACACIONES_DISPONIBLES',
                ]));

                $fechasVacaciones = $this->extraerFechasVacaciones($row, $headers);
                $diasHistoricos = count($fechasVacaciones);

                $areaId = null;
                if ($departamento) {
                    [$areaId, $areaCreada] = $this->obtenerOCrearArea($departamento);
                    if ($areaCreada) {
                        $areasCreadas++;
                    }
                }

                $liderId = null;
                if ($jefeDirecto) {
                    [$liderId, $liderCreado] = $this->obtenerOCrearLider($jefeDirecto, $areaId);
                    if ($liderCreado) {
                        $lideresCreados++;
                    }
                }

                $empleado = $this->buscarEmpleado($numeroEmpleado, $curp, $rfc, $nombre);
                $esNuevo = ! $empleado;
                $saldoOficial = round((float) ($diasDisponiblesExcel ?? 0), 2);
                $vacacionesAjuste = 0;

                $data = [
                    'area_id' => $areaId,
                    'lider_id' => $liderId,
                    'numero_empleado' => $numeroEmpleado,
                    'curp' => $curp,
                    'rfc' => $rfc,
                    'nombre' => $nombre,
                    'correo' => $correo,
                    'puesto' => $puesto,
                    'fecha_ingreso' => $fechaIngreso,
                    'es_lider' => false,
                    'activo' => true,
                    'vacaciones_ajuste' => $vacacionesAjuste,
                    'vacaciones_usados' => $diasHistoricos,
                    'vacaciones_pendientes' => $saldoOficial,
                    'dias_vacaciones' => $diasGanadosAlDia,
                    'dias_vacaciones_usados' => $diasHistoricos,
                    'departamento' => $departamento,
                    'updated_at' => now(),
                ];

                $data = $this->filtrarColumnas('empleados', $data);

                if ($empleado) {
                    DB::table('empleados')->where('id', $empleado->id)->update($data);
                    $empleadoId = $empleado->id;
                    $actualizados++;
                } else {
                    if (Schema::hasColumn('empleados', 'created_at')) {
                        $data['created_at'] = now();
                    }

                    $empleadoId = DB::table('empleados')->insertGetId($data);
                    $creados++;
                }

                $vacacionesReemplazadas += $this->eliminarVacacionesHistoricasImportadas($empleadoId);

                foreach ($fechasVacaciones as $fechaVacacion) {
                    $resultado = $this->guardarVacacionHistorica($empleadoId, $areaId, $liderId, $fechaVacacion);

                    if ($resultado === 'creada') {
                        $vacacionesCreadas++;
                    } else {
                        $vacacionesOmitidas++;
                    }
                }
            }

            DB::commit();
        } catch (\Throwable $e) {
            DB::rollBack();

            return back()->with('error', 'Error al importar: ' . $e->getMessage());
        }

        return back()->with('resultado_importacion', [
            'creados' => $creados,
            'actualizados' => $actualizados,
            'omitidos' => $omitidos,
            'areas_creadas' => $areasCreadas,
            'lideres_creados' => $lideresCreados,
            'vacaciones_creadas' => $vacacionesCreadas,
            'vacaciones_omitidas' => $vacacionesOmitidas,
            'vacaciones_reemplazadas' => $vacacionesReemplazadas,
            'errores' => $errores,
        ]);
    }

    public function update(Request $request, Empleado $empleado)
    {
        $validated = $request->validate([
            'area_id' => ['nullable', 'exists:areas,id'],
            'lider_id' => ['nullable', 'exists:empleados,id'],
            'numero_empleado' => ['nullable', 'string', 'max:50'],
            'curp' => ['nullable', 'string', 'max:18'],
            'rfc' => ['nullable', 'string', 'max:13'],
            'nombre' => ['required', 'string', 'max:255'],
            'correo' => ['nullable', 'email', 'max:255'],
            'puesto' => ['nullable', 'string', 'max:255'],
            'fecha_ingreso' => ['nullable', 'date'],
            'vacaciones_ajuste' => ['nullable', 'numeric'],
            'es_lider' => ['nullable', 'boolean'],
            'activo' => ['nullable', 'boolean'],
            'dias_laborales' => ['nullable', 'array'],
            'dias_laborales.*' => ['integer', 'between:1,7'],
        ]);

        $validated['curp'] = $this->normalizarClave($validated['curp'] ?? null);
        $validated['rfc'] = $this->normalizarClave($validated['rfc'] ?? null);
        $validated['vacaciones_ajuste'] = $validated['vacaciones_ajuste'] ?? 0;
        $validated['es_lider'] = $request->boolean('es_lider');
        $validated['activo'] = $request->boolean('activo');
        $validated['dias_laborales'] = $request->filled('dias_laborales')
            ? array_values(array_unique(array_map('intval', $request->input('dias_laborales', []))))
            : null;

        $empleado->update($validated);

        return back()->with('success', 'Empleado actualizado correctamente.');
    }

    private function ensureImportSchema(): void
    {
        if (! Schema::hasTable('areas')) {
            Schema::create('areas', function ($table) {
                $table->id();
                $table->string('nombre')->unique();
                $table->text('descripcion')->nullable();
                $table->boolean('activo')->default(true);
                $table->timestamps();
            });
        }

        if (! Schema::hasTable('empleados') || ! Schema::hasTable('tipos_permisos') || ! Schema::hasTable('permisos_solicitudes')) {
            return;
        }

        $this->obtenerTipoVacacionesId();
    }

    private function leerArchivo($archivo): array
    {
        $extension = strtolower($archivo->getClientOriginalExtension());
        $path = $archivo->getRealPath();

        if (in_array($extension, ['csv', 'txt'], true)) {
            return $this->leerCsv($path);
        }

        $spreadsheet = IOFactory::load($path);
        $sheet = $spreadsheet->getActiveSheet();
        $rawRows = $sheet->toArray(null, true, true, false);

        return array_values(array_map(fn ($row) => array_values($row), $rawRows));
    }

    private function leerCsv(string $path): array
    {
        $content = file_get_contents($path);

        if ($content === false) {
            return [];
        }

        if (! mb_check_encoding($content, 'UTF-8')) {
            $content = mb_convert_encoding($content, 'UTF-8', 'Windows-1252,ISO-8859-1,UTF-8');
        }

        $firstLine = strtok($content, "\n") ?: '';
        $delimiter = substr_count($firstLine, ';') >= substr_count($firstLine, ',') ? ';' : ',';

        $handle = fopen('php://temp', 'r+');
        fwrite($handle, $content);
        rewind($handle);

        $rows = [];
        while (($row = fgetcsv($handle, 0, $delimiter)) !== false) {
            $rows[] = array_values($row);
        }

        fclose($handle);

        return $rows;
    }

    private function detectHeaders(array $rows): array
    {
        $bestRow = 0;
        $bestHeaders = [];
        $bestScore = 0;

        foreach ($rows as $index => $row) {
            if ($index > 15) {
                break;
            }

            $headers = [];

            foreach ($row as $columnIndex => $value) {
                $normalized = $this->normalizeHeader($value);

                if ($normalized !== '') {
                    $headers[$normalized] = $columnIndex;
                }
            }

            $score = 0;
            foreach (['CLAVE', 'NOMBRE', 'DEPARTAMENTO', 'PUESTO', 'FECHA_INGRESO'] as $required) {
                if (isset($headers[$required])) {
                    $score++;
                }
            }

            if ($score > $bestScore) {
                $bestScore = $score;
                $bestRow = $index;
                $bestHeaders = $headers;
            }
        }

        return [$bestRow, $bestHeaders];
    }

    private function value(array $row, array $headers, array $names)
    {
        foreach ($names as $name) {
            $key = $this->normalizeHeader($name);

            if (isset($headers[$key])) {
                $columnIndex = $headers[$key];
                $value = $row[$columnIndex] ?? null;

                if ($value !== null && trim((string) $value) !== '') {
                    return trim((string) $value);
                }
            }
        }

        return null;
    }

    private function extraerFechasVacaciones(array $row, array $headers): array
    {
        $columnasConEncabezado = array_values($headers);
        $fechas = [];

        foreach ($row as $columnIndex => $value) {
            if (in_array($columnIndex, $columnasConEncabezado, true)) {
                continue;
            }

            if ($value === null || trim((string) $value) === '') {
                continue;
            }

            $posiblesValores = preg_split('/[\n\r,;]+/', (string) $value);

            foreach ($posiblesValores as $posibleFecha) {
                $fecha = $this->fecha(trim($posibleFecha));

                if ($fecha) {
                    $fechas[] = $fecha;
                }
            }
        }

        return collect($fechas)->unique()->values()->all();
    }

    private function guardarVacacionHistorica(int $empleadoId, ?int $areaId, ?int $liderId, string $fecha): string
    {
        $tipoVacacionesId = $this->obtenerTipoVacacionesId();

        $existeManual = DB::table('permisos_solicitudes')
            ->where('empleado_id', $empleadoId)
            ->whereDate('fecha_inicio', $fecha)
            ->whereDate('fecha_fin', $fecha)
            ->where('motivo', '!=', $this->motivoImportado)
            ->exists();

        if ($existeManual) {
            return 'omitida';
        }

        $data = [
            'tipo_permiso_id' => $tipoVacacionesId,
            'empleado_id' => $empleadoId,
            'area_id' => $areaId,
            'lider_id' => $liderId,
            'fecha_inicio' => $fecha,
            'fecha_fin' => $fecha,
            'dias_solicitados' => 1,
            'motivo' => $this->motivoImportado,
            'estatus' => 'formato_recibido',
            'formato_recibido' => true,
            'formato_recibido_at' => now(),
            'observaciones_rh' => 'Registro histórico importado desde el archivo de saldos de vacaciones.',
            'created_at' => now(),
            'updated_at' => now(),
        ];

        DB::table('permisos_solicitudes')->insert($this->filtrarColumnas('permisos_solicitudes', $data));

        return 'creada';
    }

    private function eliminarVacacionesHistoricasImportadas(int $empleadoId): int
    {
        if (! Schema::hasTable('permisos_solicitudes')) {
            return 0;
        }

        return DB::table('permisos_solicitudes')
            ->where('empleado_id', $empleadoId)
            ->where('motivo', $this->motivoImportado)
            ->delete();
    }

    private function obtenerTipoVacacionesId(): ?int
    {
        if (! Schema::hasTable('tipos_permisos')) {
            return null;
        }

        $tipo = DB::table('tipos_permisos')
            ->where(function ($q) {
                if (Schema::hasColumn('tipos_permisos', 'slug')) {
                    $q->where('slug', 'vacaciones');
                }

                $q->orWhere('nombre', 'like', '%Vacaciones%');
            })
            ->first();

        if ($tipo) {
            return $tipo->id;
        }

        $data = [
            'nombre' => 'Vacaciones',
            'slug' => 'vacaciones',
            'descripcion' => 'Días de vacaciones que descuentan saldo disponible.',
            'descuenta_vacaciones' => true,
            'requiere_saldo' => true,
            'requiere_firma_colaborador' => true,
            'requiere_firma_lider' => true,
            'requiere_recepcion_rh' => true,
            'activo' => true,
            'created_at' => now(),
            'updated_at' => now(),
        ];

        return DB::table('tipos_permisos')->insertGetId($this->filtrarColumnas('tipos_permisos', $data));
    }

    private function obtenerOCrearArea(string $nombre): array
    {
        $nombre = $this->limpiarTexto($nombre);

        $area = DB::table('areas')->where('nombre', $nombre)->first();

        if ($area) {
            return [$area->id, false];
        }

        $data = [
            'nombre' => $nombre,
            'activo' => true,
            'created_at' => now(),
            'updated_at' => now(),
        ];

        return [DB::table('areas')->insertGetId($this->filtrarColumnas('areas', $data)), true];
    }

    private function obtenerOCrearLider(string $nombre, ?int $areaId): array
    {
        $nombre = $this->limpiarTexto($nombre);

        $lider = DB::table('empleados')->where('nombre', $nombre)->first();

        if ($lider) {
            DB::table('empleados')->where('id', $lider->id)->update($this->filtrarColumnas('empleados', [
                'area_id' => $lider->area_id ?? $areaId,
                'es_lider' => true,
                'activo' => true,
                'updated_at' => now(),
            ]));

            return [$lider->id, false];
        }

        $data = [
            'area_id' => $areaId,
            'nombre' => $nombre,
            'es_lider' => true,
            'activo' => true,
            'vacaciones_ajuste' => 0,
            'vacaciones_usados' => 0,
            'vacaciones_pendientes' => 0,
            'created_at' => now(),
            'updated_at' => now(),
        ];

        return [DB::table('empleados')->insertGetId($this->filtrarColumnas('empleados', $data)), true];
    }

    private function buscarEmpleado(?string $numeroEmpleado, ?string $curp, ?string $rfc, ?string $nombre)
    {
        if ($numeroEmpleado && Schema::hasColumn('empleados', 'numero_empleado')) {
            $empleado = DB::table('empleados')->where('numero_empleado', $numeroEmpleado)->first();
            if ($empleado) return $empleado;
        }

        if ($curp && Schema::hasColumn('empleados', 'curp')) {
            $empleado = DB::table('empleados')->where('curp', $curp)->first();
            if ($empleado) return $empleado;
        }

        if ($rfc && Schema::hasColumn('empleados', 'rfc')) {
            $empleado = DB::table('empleados')->where('rfc', $rfc)->first();
            if ($empleado) return $empleado;
        }

        if ($nombre && Schema::hasColumn('empleados', 'nombre')) {
            return DB::table('empleados')->where('nombre', $nombre)->first();
        }

        return null;
    }

    private function diasVacacionesCorrespondientes(?string $fechaIngreso): int
    {
        if (! $fechaIngreso) {
            return 0;
        }

        $fecha = Carbon::parse($fechaIngreso);
        $anios = (int) $fecha->diffInYears(now());

        if ($anios < 1) {
            return 0;
        }

        return match (true) {
            $anios === 1 => 12,
            $anios === 2 => 14,
            $anios === 3 => 16,
            $anios === 4 => 18,
            $anios === 5 => 20,
            default => 20 + (int) (floor(($anios - 6) / 5) + 1) * 2,
        };
    }

    private function filtrarColumnas(string $table, array $data): array
    {
        if (! Schema::hasTable($table)) {
            return [];
        }

        $columns = Schema::getColumnListing($table);

        return collect($data)
            ->filter(fn ($value) => $value !== null && $value !== '')
            ->only($columns)
            ->all();
    }

    private function decimal($value): ?float
    {
        if ($value === null || $value === '') {
            return null;
        }

        $value = trim((string) $value);
        $value = str_replace(['$', ' '], '', $value);

        if (str_contains($value, ',') && ! str_contains($value, '.')) {
            $value = str_replace(',', '.', $value);
        } else {
            $value = str_replace(',', '', $value);
        }

        $value = preg_replace('/[^0-9.\-]/', '', $value);

        if ($value === '' || ! is_numeric($value)) {
            return null;
        }

        return round((float) $value, 2);
    }

    private function fecha($value): ?string
    {
        if ($value === null || $value === '') {
            return null;
        }

        if (is_numeric($value)) {
            $numeric = (float) $value;

            if ($numeric < 20000 || $numeric > 60000) {
                return null;
            }

            try {
                return ExcelDate::excelToDateTimeObject($numeric)->format('Y-m-d');
            } catch (\Throwable $e) {
                return null;
            }
        }

        $value = trim((string) $value);

        $formats = [
            'd/m/Y',
            'd-m-Y',
            'Y-m-d',
            'd/m/y',
            'd-m-y',
            'm/d/Y',
            'm-d-Y',
        ];

        foreach ($formats as $format) {
            $date = DateTime::createFromFormat($format, $value);

            if ($date instanceof DateTime) {
                $errors = DateTime::getLastErrors();

                if (($errors['warning_count'] ?? 0) === 0 && ($errors['error_count'] ?? 0) === 0) {
                    return $date->format('Y-m-d');
                }
            }
        }

        return null;
    }

    private function normalizeHeader($value): string
    {
        $value = trim((string) $value);

        $replacements = [
            'Á' => 'A', 'É' => 'E', 'Í' => 'I', 'Ó' => 'O', 'Ú' => 'U',
            'Ü' => 'U', 'Ñ' => 'N',
            'á' => 'A', 'é' => 'E', 'í' => 'I', 'ó' => 'O', 'ú' => 'U',
            'ü' => 'U', 'ñ' => 'N',
        ];

        $value = strtr($value, $replacements);
        $value = strtoupper($value);
        $value = preg_replace('/[^A-Z0-9]+/', '_', $value);

        return trim($value, '_');
    }

    private function limpiarTexto($value): ?string
    {
        if ($value === null) {
            return null;
        }

        $value = trim(preg_replace('/\s+/', ' ', (string) $value));

        return $value !== '' ? $value : null;
    }

    private function normalizarClave(?string $valor): ?string
    {
        $valor = Str::upper(preg_replace('/[^A-Za-z0-9]/', '', (string) $valor));

        return $valor !== '' ? $valor : null;
    }
}
